package com.example.practica18_poleev

class LoginPassword {
    public  var Login: String? = null
    public  var Password : String? = null
    fun Return() : String{
        return Login + Password
    }
}