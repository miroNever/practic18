package com.example.practica18_poleev

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {
    lateinit var str1:TextView
    lateinit var str2: TextView
    private var a1 : String = ""
    private var a2 : String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        str1 = findViewById(R.id.str1)
        str2 = findViewById(R.id.str2)

        a1 = intent.getStringExtra("title").toString()
        a2 = intent.getStringExtra("description").toString()

        str1.setText(a1)
        str2.setText(a2)

    }

    fun next(view: View) {

        val intent = Intent(this,Add_Case:: class.java)
        intent.putExtra("title", a1)
        intent.putExtra("description", a2)
        startActivity(intent)
    }
}