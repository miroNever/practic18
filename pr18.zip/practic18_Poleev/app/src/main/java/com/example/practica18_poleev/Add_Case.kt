package com.example.practica18_poleev

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.view.View
import android.widget.EditText
import com.google.gson.Gson

class Add_Case : AppCompatActivity() {
    lateinit var pref: SharedPreferences
    lateinit var title: EditText
    lateinit var description : EditText
    private lateinit var a1 : String
    private lateinit var a2 : String
    private var a3:String="0"

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_case)
        title = findViewById(R.id.title)
        description = findViewById(R.id.description)
        if(a3 == "1") {
            a1 = intent.getStringExtra("nazv4").toString()
            a2 = intent.getStringExtra("nazv5").toString()
            title.setText(a1)
            description.setText(a2)
        }
    }

    fun add(view: View) {
        if(title.toString().isNotEmpty() && description.toString().isNotEmpty()) {
            val st1 = title.text.toString()
            val st2 = description.text.toString()
            val z1 = Gson().toJson((st1))
            val z2 = Gson().toJson((st2))
            pref = getPreferences(MODE_PRIVATE)
            val ed: SharedPreferences.Editor = pref.edit()
            ed.putString("title", title.getText().toString())
            ed.putString("description", description.getText().toString())
            ed.apply()

            val intent = Intent(this, MainActivity2::class.java)
            intent.putExtra("title", z1)
            intent.putExtra("description", z2)

            startActivity(intent)
        }
        else {
            val alert = AlertDialog.Builder(this)
                .setTitle("Ошибка")
                .setMessage("У вас не заполненые поля")
                .setPositiveButton("Ok", null)
                .create()
                .show()
        }
    }
}