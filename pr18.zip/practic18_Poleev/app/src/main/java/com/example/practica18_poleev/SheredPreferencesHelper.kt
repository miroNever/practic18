package com.example.practica18_poleev

import android.content.Context
import com.google.gson.Gson
object SheredPreferencesHelper {
    private const val Prefs_Name = "MyPrefsFile"
    private const val Tickets_Key = "Tickets"

    fun saveTickets(context: Context, ticket: List<Ticket>){
        val prefs = context.getSharedPreferences(Prefs_Name, Context.MODE_PRIVATE)
        val ed = prefs.edit()
        val gson = Gson()
        val json = gson.toJson(ticket)
        ed.putString(Tickets_Key, json)
        ed.apply()
    }
    fun loadTickets(context: Context): List<Ticket>{
        val prefs = context.getSharedPreferences(Prefs_Name, Context.MODE_PRIVATE)
        val gson = Gson()
        val json = prefs.getString(Tickets_Key, null)
        if (json != null) {
            return  gson.fromJson (json, Array<Ticket>:: class.java).toList()
        }
        else
            return emptyList()
    }
    fun clearTickets(context: Context){
        val pref = context.getSharedPreferences(Prefs_Name, Context.MODE_PRIVATE)
        pref.edit().remove(Tickets_Key).apply()
    }
}